# Smart Parking Predictor — Backend

Starter REST API using Java 17, Spring Boot, Spring Data JPA, Maven, and MySQL.

## Setup
1. Install Java 17+, MySQL, and Maven (or use a Maven wrapper).
2. In MySQL, run: `CREATE DATABASE smart_parking;`
3. Set `DB_USERNAME` and `DB_PASSWORD` environment variables, or adjust your local configuration. Do not commit passwords.
4. From this folder run: `mvn spring-boot:run`
5. Backend URL: `http://localhost:8080`

## Endpoints
- `GET /api/slots` — list slots
- `POST /api/slots` — create a slot
- `GET /api/bookings` — list bookings
- `POST /api/bookings` — create a booking
- `GET /api/predict?location=Hyderabad&vehicleType=CAR&date=2026-10-15&startTime=10:00:00&endTime=11:00:00` — estimate availability

Example slot JSON:
```json
{"slotNumber":"A01","location":"Hyderabad","vehicleType":"CAR","active":true}
```

Example booking JSON:
```json
{"vehicleNumber":"TS09AB1234","vehicleType":"CAR","location":"Hyderabad","bookingDate":"2026-10-15","startTime":"10:00:00","endTime":"11:00:00"}
```

The availability estimate is based on saved bookings. It is not a trained machine-learning model. This starter project is for development and should be hardened before production use.
