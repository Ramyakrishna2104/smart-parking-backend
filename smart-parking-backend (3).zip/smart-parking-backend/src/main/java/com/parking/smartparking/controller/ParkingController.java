package com.parking.smartparking.controller;

import com.parking.smartparking.model.Booking;
import com.parking.smartparking.model.ParkingSlot;
import com.parking.smartparking.service.ParkingService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:5173")
public class ParkingController {
    private final ParkingService service;

    public ParkingController(ParkingService service) {
        this.service = service;
    }

    @GetMapping("/slots")
    public List<ParkingSlot> getSlots() {
        return service.getSlots();
    }

    @PostMapping("/slots")
    public ResponseEntity<ParkingSlot> addSlot(@RequestBody ParkingSlot slot) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.addSlot(slot));
    }

    @GetMapping("/bookings")
    public List<Booking> getBookings() {
        return service.getBookings();
    }

    @PostMapping("/bookings")
    public ResponseEntity<Booking> createBooking(@RequestBody BookingRequest request) {
        Booking booking = service.createBooking(
            request.vehicleNumber(), request.vehicleType(), request.location(),
            request.bookingDate(), request.startTime(), request.endTime());
        return ResponseEntity.status(HttpStatus.CREATED).body(booking);
    }

    @GetMapping("/predict")
    public Map<String, Object> predict(
            @RequestParam String location,
            @RequestParam String vehicleType,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime startTime,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime endTime) {
        return service.predict(location, vehicleType, date, startTime, endTime);
    }

    public record BookingRequest(String vehicleNumber, String vehicleType,
                                 String location, LocalDate bookingDate,
                                 LocalTime startTime, LocalTime endTime) {}

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, String>> handleInvalidInput(IllegalArgumentException ex) {
        return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
    }

    @ExceptionHandler(IllegalStateException.class)
    public ResponseEntity<Map<String, String>> handleUnavailable(IllegalStateException ex) {
        return ResponseEntity.status(HttpStatus.CONFLICT)
            .body(Map.of("error", ex.getMessage()));
    }
}
