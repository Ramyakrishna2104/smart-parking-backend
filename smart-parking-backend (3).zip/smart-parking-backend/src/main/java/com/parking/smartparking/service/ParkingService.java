package com.parking.smartparking.service;

import com.parking.smartparking.model.Booking;
import com.parking.smartparking.model.ParkingSlot;
import com.parking.smartparking.repository.BookingRepository;
import com.parking.smartparking.repository.ParkingSlotRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

@Service
public class ParkingService {
    private final ParkingSlotRepository slotRepository;
    private final BookingRepository bookingRepository;

    public ParkingService(ParkingSlotRepository slotRepository,
                          BookingRepository bookingRepository) {
        this.slotRepository = slotRepository;
        this.bookingRepository = bookingRepository;
    }

    public List<ParkingSlot> getSlots() {
        return slotRepository.findAll();
    }

    public List<Booking> getBookings() {
        return bookingRepository.findAll();
    }

    public ParkingSlot addSlot(ParkingSlot slot) {
        if (blank(slot.getSlotNumber()) || blank(slot.getLocation())
                || blank(slot.getVehicleType())) {
            throw new IllegalArgumentException(
                "Slot number, location and vehicle type are required");
        }
        slot.setActive(true);
        return slotRepository.save(slot);
    }

    public Map<String, Object> predict(String location, String vehicleType,
                                       LocalDate date, LocalTime start, LocalTime end) {
        validateTime(date, start, end);
        if (blank(location) || blank(vehicleType)) {
            throw new IllegalArgumentException("Location and vehicle type are required");
        }

        List<ParkingSlot> matchingSlots = slotRepository.findAll().stream()
            .filter(ParkingSlot::isActive)
            .filter(s -> s.getLocation().equalsIgnoreCase(location))
            .filter(s -> s.getVehicleType().equalsIgnoreCase(vehicleType))
            .toList();

        List<Booking> bookings =
            bookingRepository.findByBookingDateAndStatus(date, "CONFIRMED");

        long occupied = matchingSlots.stream().filter(slot ->
            bookings.stream().anyMatch(b ->
                b.getSlot().getId().equals(slot.getId())
                && overlaps(start, end, b.getStartTime(), b.getEndTime())
            )
        ).count();

        int total = matchingSlots.size();
        int available = total - (int) occupied;

        return Map.of(
            "location", location,
            "date", date.toString(),
            "totalSlots", total,
            "bookedSlots", occupied,
            "availableSlots", available,
            "prediction", available == 0 ? "FULL"
                : available <= 2 ? "LIMITED" : "AVAILABLE",
            "note", "Estimate based on saved bookings; this is not a trained AI model."
        );
    }

    @Transactional
    public Booking createBooking(String vehicleNumber, String vehicleType,
                                 String location, LocalDate date,
                                 LocalTime start, LocalTime end) {
        if (blank(vehicleNumber) || blank(vehicleType) || blank(location)) {
            throw new IllegalArgumentException(
                "Vehicle number, vehicle type and location are required");
        }
        validateTime(date, start, end);

        List<Booking> bookings =
            bookingRepository.findByBookingDateAndStatus(date, "CONFIRMED");

        ParkingSlot selected = slotRepository.findAll().stream()
            .filter(ParkingSlot::isActive)
            .filter(s -> s.getLocation().equalsIgnoreCase(location))
            .filter(s -> s.getVehicleType().equalsIgnoreCase(vehicleType))
            .filter(s -> bookings.stream().noneMatch(b ->
                b.getSlot().getId().equals(s.getId())
                && overlaps(start, end, b.getStartTime(), b.getEndTime())
            ))
            .findFirst()
            .orElseThrow(() -> new IllegalStateException(
                "No available parking slot for the selected time"));

        Booking booking = new Booking();
        booking.setVehicleNumber(vehicleNumber.trim().toUpperCase());
        booking.setVehicleType(vehicleType.trim().toUpperCase());
        booking.setLocation(location.trim());
        booking.setBookingDate(date);
        booking.setStartTime(start);
        booking.setEndTime(end);
        booking.setStatus("CONFIRMED");
        booking.setSlot(selected);
        return bookingRepository.save(booking);
    }

    private boolean overlaps(LocalTime start1, LocalTime end1,
                             LocalTime start2, LocalTime end2) {
        return start1.isBefore(end2) && start2.isBefore(end1);
    }

    private void validateTime(LocalDate date, LocalTime start, LocalTime end) {
        if (date == null || start == null || end == null || !start.isBefore(end)) {
            throw new IllegalArgumentException(
                "Enter a valid date and a start time before the end time");
        }
    }

    private boolean blank(String value) {
        return value == null || value.isBlank();
    }
}
