package com.parking.smartparking.model;

import jakarta.persistence.*;

@Entity
@Table(name = "parking_slots")
public class ParkingSlot {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String slotNumber;
    private String location;
    private String vehicleType;
    private boolean active = true;

    public ParkingSlot() {}

    public Long getId() { return id; }
    public String getSlotNumber() { return slotNumber; }
    public String getLocation() { return location; }
    public String getVehicleType() { return vehicleType; }
    public boolean isActive() { return active; }

    public void setId(Long id) { this.id = id; }
    public void setSlotNumber(String slotNumber) { this.slotNumber = slotNumber; }
    public void setLocation(String location) { this.location = location; }
    public void setVehicleType(String vehicleType) { this.vehicleType = vehicleType; }
    public void setActive(boolean active) { this.active = active; }
}
